# Temperature Report Build Notes

- Source table: `neuract__TEMPERATURES` inside `C:\Users\Alfred\NeuraReport\test - Copy (2).db`.
- Temperature columns detected: 12 sensors.
- Daily aggregation: AVG of all temperature readings for each date.
- Row average: Average across all sensors for each day.
- Totals: MAX reading for each sensor, and overall average.
- Optional parameters: `from_date`, `to_date`.
